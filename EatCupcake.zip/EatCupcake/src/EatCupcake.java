import java.util.Scanner;

public class EatCupcake {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Did anyone see you?");
        String response = input.nextLine();

//YES
        if (response.equals("YES.")) {
            System.out.println("Was it a boss/lover/parent?");
            response = input.nextLine();

            if (response.equals("YES.")) {
                System.out.println("Was it expensive?");
                response = input.nextLine();

                if (response.equals("YES.")) {
                    System.out.println("Can you cut off the part that touched the floor?");
                    response = input.nextLine();

                    if (response.equals("YES.")) {
                        System.out.println("EAT IT.");
                    } else if (response.equalsIgnoreCase("NO.")) {
                        System.out.println("YOUR CALL");
                    }

                } else if (response.equals("NO.")) {
                    System.out.println("Is it chocolate?");
                    response = input.nextLine();

                    if (response.equals("YES.")) {
                        System.out.println("EAT IT.");
                    } else if (response.equals("NO.")) {
                        System.out.println("DON'T EAT IT");
                    }
                }
            } else if (response.equals("NO.")) {
                System.out.println("EAT IT.");
            }
//NO
      } else if (response.equals("NO.")) {
//        }else {
            System.out.println("Was it sticky?");
            response = input.nextLine();

            if (response.equals("YES.")) {
                System.out.println("Is it a raw steak?");
                response = input.nextLine();

                if (response.equals("YES.")) {
                    System.out.println("Are you a puma?");
                    response = input.nextLine();

                    if (response.equals("YES.")) {
                        System.out.println("EAT IT.");
                    } else if (response.equals("NO.")) {
                        System.out.println("DON'T EAT IT");
                    }

                } else if (response.equals("NO.")) {
                    System.out.println("Did the cat lick it?");
                    response = input.nextLine();

                    if (response.equals("YES.")) {
                        System.out.println("Is your cat healthy?");
                        response = input.nextLine();

                        if (response.equals("YES.")) {
                            System.out.println("EAT IT.");
                        } else if (response.equals("NO.")) {
                            System.out.println("YOUR CALL");
                        }

                    } else if (response.equals("NO.")) {
                        System.out.println("EAT IT.");
                    }
                }

            } else if (response.equals("NO.")) {
                System.out.println("Is it an Emausaurus?");
                response = input.nextLine();

                if (response.equals("YES.")) {
                    System.out.println("Are you a Megalosaurus?");
                    response = input.nextLine();

                    if (response.equals("YES.")) {
                        System.out.println("EAT IT.");
                    } else if (response.equals("NO.")) {
                        System.out.println("DON'T EAT IT");
                    }

                } else if (response.equals("NO.")) {
                    System.out.println("Did the cat lick it?");
                    response = input.nextLine();

                    if (response.equalsIgnoreCase("YES.")) {
                        System.out.println("Is your cat healthy?");
                        response = input.nextLine();

                        if (response.equalsIgnoreCase("YES.")) {
                            System.out.println("EAT IT.");
                        } else if (response.equalsIgnoreCase("NO.")) {
                            System.out.println("YOUR CALL");
                        }

                    } else if (response.equalsIgnoreCase("NO.")) {
                        System.out.println("EAT IT.");
                    }
                }
            }
        }

    }
}