package Test;

public class Pi {
    public static void main(String[] args) {
        double pi = 3.14159265359;
        System.out.println(pi);
    }
}
