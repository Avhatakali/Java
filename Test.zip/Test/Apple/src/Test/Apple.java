package Test;

public class Apple {
    public static void main(String[] args) {
        String apple = "apple";
        System.out.println(apple);
    }
}
